package com.example.UserService.API;

import org.json.simple.JSONObject;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
//import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ResponseStatusException;

import com.example.UserService.model.Login;
import com.example.UserService.model.User;
import com.example.UserService.service.UserService;



@RestController
@CrossOrigin
@RequestMapping(value="/userservice")
public class UserServiceAPI {
	
	@Autowired
	private UserService usrService;
	@Autowired
	Environment env;
	
	@PostMapping(value="/addUser")
	public JSONObject addUser(@RequestBody User userDetails) throws Exception{
		try {
			usrService.addUser(userDetails);
			String name=userDetails.getUserName();
			JSONObject obj=new JSONObject();
			obj.put("User", "successfully added");
			return obj;
		} catch(Exception e) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	
	
	
	@PostMapping(value="/authenticateUser")
	public JSONObject authenticateUser(@RequestBody Login loginDetails) throws Exception{
		JSONObject obj=new JSONObject();
		try {
			usrService.authenticateUser(loginDetails.getUserName(),loginDetails.getPassword());
			
			obj.put("Message", "Authenticated");
			return obj;
		} 
		catch(Exception e){
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,env.getProperty(e.getMessage()));
		}
	}
	

}
