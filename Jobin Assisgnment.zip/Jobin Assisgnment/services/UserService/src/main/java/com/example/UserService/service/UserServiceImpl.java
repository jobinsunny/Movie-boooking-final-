package com.example.UserService.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.UserService.model.Login;
import com.example.UserService.model.User;
import com.example.UserService.user.UserDAO;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDAO userDao;
	
	@Override	
	public void authenticateUser(String userName, String password) throws Exception{
		Login user1=new Login();
		user1=userDao.authenticateUser(userName,password);
		if(user1==null) {
			throw new Exception("Service.INVALID_USERNAME_OR_PASSWORD");
		}
	}

	@Override
	public void addUser(User user) throws Exception{
		User usr=new User();
		usr=userDao.getUser(user.getUserName());
		if(usr==null) {
			userDao.addUser(user);
		}
		if(usr!=null) {
			throw new Exception("Service.USER_ALREADY_EXISTS");
		}
		
		
		
	}

}
